import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { ArtworkCard } from '@/components/artwork-card';
import { CreateArtworkModal } from '@/components/create-artwork-modal';
import { PlusIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Artwork } from '@shared/schema';
import { useAuth } from '@/lib/firebase';

export default function MyArtworks() {
  const { user, loading: authLoading } = useAuth();
  const [createModalOpen, setCreateModalOpen] = useState(false);
  
  // Fetch all user artworks
  const { 
    data: artworks,
    isLoading: artworksLoading
  } = useQuery<Artwork[]>({
    queryKey: ['/api/artworks'],
    enabled: !!user
  });

  const isLoading = authLoading || artworksLoading;

  if (!user && !authLoading) {
    // Redirect to login if not authenticated and not still loading
    window.location.href = '/login';
    return null;
  }

  return (
    <div>
      <header className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold text-neutral-dark">My Artworks</h1>
          <p className="mt-2 text-gray-600 max-w-3xl">
            View and manage all your AR-enhanced artworks. Edit details, check viewer statistics, or remove artworks.
          </p>
        </div>
        <Button 
          onClick={() => setCreateModalOpen(true)}
          className="mt-4 md:mt-0"
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          New Artwork
        </Button>
      </header>

      {isLoading ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden shadow">
              <div className="relative pb-[66.66%] bg-gray-100">
                <Skeleton className="absolute h-full w-full" />
              </div>
              <CardContent className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-full mb-4" />
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-1/3" />
                  <div className="flex space-x-2">
                    <Skeleton className="h-6 w-6 rounded-full" />
                    <Skeleton className="h-6 w-6 rounded-full" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : artworks && artworks.length > 0 ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {artworks.map(artwork => (
            <ArtworkCard key={artwork.id} artwork={artwork} />
          ))}
        </div>
      ) : (
        <Card className="p-8 text-center">
          <h3 className="text-lg font-medium text-neutral-dark mb-2">No artworks yet</h3>
          <p className="text-gray-500 mb-4">Get started by creating your first AR artwork.</p>
          <Button onClick={() => setCreateModalOpen(true)} className="mx-auto">
            Create Artwork
          </Button>
        </Card>
      )}

      {/* Create Artwork Modal */}
      <CreateArtworkModal 
        open={createModalOpen} 
        onOpenChange={setCreateModalOpen} 
      />
    </div>
  );
}
