import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { CreateArtworkModal } from '@/components/create-artwork-modal';
import { Button } from '@/components/ui/button';
import { PlusIcon } from 'lucide-react';
import { ArtworkCard } from '@/components/artwork-card';
import { Link } from 'wouter';
import { Artwork, UserStats } from '@shared/schema';
import { useAuth } from '@/lib/firebase';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [createModalOpen, setCreateModalOpen] = useState(false);
  
  // Fetch user stats
  const { 
    data: stats,
    isLoading: statsLoading
  } = useQuery<UserStats>({
    queryKey: ['/api/stats'],
    enabled: !!user
  });

  // Fetch recent artworks
  const { 
    data: recentArtworks,
    isLoading: artworksLoading
  } = useQuery<Artwork[]>({
    queryKey: ['/api/artworks', 'recent'],
    enabled: !!user
  });

  const isLoading = authLoading || statsLoading || artworksLoading;

  if (!user && !authLoading) {
    // Redirect to login if not authenticated and not still loading
    window.location.href = '/login';
    return null;
  }

  return (
    <div className="dashboard-view">
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-neutral-dark">Artist Dashboard</h1>
        <p className="mt-2 text-gray-600 max-w-3xl">Create, manage, and track your AR-powered artworks. Upload images and bring them to life with digital content.</p>
      </header>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {/* Statistics Cards */}
        <Card>
          <CardContent className="px-4 py-5 sm:p-6">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Total Artworks</dt>
              {isLoading ? (
                <Skeleton className="h-10 w-16 mt-1" />
              ) : (
                <dd className="mt-1 text-3xl font-semibold text-neutral-dark">
                  {stats?.totalArtworks || 0}
                </dd>
              )}
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="px-4 py-5 sm:p-6">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Total Views</dt>
              {isLoading ? (
                <Skeleton className="h-10 w-20 mt-1" />
              ) : (
                <dd className="mt-1 text-3xl font-semibold text-neutral-dark">
                  {stats?.totalViews || 0}
                </dd>
              )}
            </dl>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="px-4 py-5 sm:p-6">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">Engagement Rate</dt>
              {isLoading ? (
                <Skeleton className="h-10 w-16 mt-1" />
              ) : (
                <dd className="mt-1 text-3xl font-semibold text-[#4CAF50]">
                  {stats?.engagementRate || '0%'}
                </dd>
              )}
            </dl>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-heading font-bold text-neutral-dark">Recent Artworks</h2>
          <Link href="/my-artworks">
            <a className="text-[#6C63FF] hover:text-[#5A52D9] font-medium flex items-center">
              View all
              <svg className="ml-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </a>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="overflow-hidden shadow">
                <div className="relative pb-[66.66%] bg-gray-100">
                  <Skeleton className="absolute h-full w-full" />
                </div>
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-1/3" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-6 w-6 rounded-full" />
                      <Skeleton className="h-6 w-6 rounded-full" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : recentArtworks && recentArtworks.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {recentArtworks.map(artwork => (
              <ArtworkCard key={artwork.id} artwork={artwork} />
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center">
            <h3 className="text-lg font-medium text-neutral-dark mb-2">No artworks yet</h3>
            <p className="text-gray-500 mb-4">Get started by creating your first AR artwork.</p>
            <Button onClick={() => setCreateModalOpen(true)} className="mx-auto">
              Create Artwork
            </Button>
          </Card>
        )}

        {/* Create New Artwork Button (Fixed) */}
        <div className="fixed bottom-8 right-8">
          <Button 
            onClick={() => setCreateModalOpen(true)}
            size="icon" 
            className="h-14 w-14 rounded-full shadow-lg"
          >
            <PlusIcon className="h-6 w-6" />
            <span className="sr-only">Create new artwork</span>
          </Button>
        </div>
      </div>

      {/* Create Artwork Modal */}
      <CreateArtworkModal 
        open={createModalOpen} 
        onOpenChange={setCreateModalOpen} 
      />
    </div>
  );
}
