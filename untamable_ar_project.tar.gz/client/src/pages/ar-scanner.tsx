import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ARScannerView } from '@/components/ui/mobile-preview';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Artwork } from '@shared/schema';
import { useAuth } from '@/lib/firebase';

export default function ARScanner() {
  const { user, loading: authLoading } = useAuth();
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  
  // Fetch all artworks for demo purposes
  const { 
    data: artworks,
    isLoading: artworksLoading
  } = useQuery<Artwork[]>({
    queryKey: ['/api/artworks'],
    enabled: !!user
  });

  const isLoading = authLoading || artworksLoading;

  // Simulate AR experience by selecting a random artwork after loading
  useEffect(() => {
    if (artworks && artworks.length > 0 && !selectedArtwork) {
      // In a real app, this would be triggered by scanning a real artwork
      const randomIndex = Math.floor(Math.random() * artworks.length);
      setSelectedArtwork(artworks[randomIndex]);
    }
  }, [artworks, selectedArtwork]);

  return (
    <div>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-neutral-dark">AR Scanner</h1>
        <p className="mt-2 text-gray-600 max-w-3xl">
          Preview how your AR experiences will look in the mobile app. Scan artworks to bring them to life.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div>
          <ARScannerView />
        </div>

        <div>
          <Card className="mb-6">
            <CardContent className="p-6">
              <h2 className="text-xl font-heading font-bold text-neutral-dark mb-4">How to Use the AR Scanner</h2>
              <ol className="space-y-4">
                <li className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 bg-[#6C63FF] text-white rounded-full flex items-center justify-center font-medium">1</div>
                  <p className="text-gray-600">Download the Untamable mobile app from App Store or Google Play</p>
                </li>
                <li className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 bg-[#6C63FF] text-white rounded-full flex items-center justify-center font-medium">2</div>
                  <p className="text-gray-600">Open the app and tap on the Scanner icon</p>
                </li>
                <li className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 bg-[#6C63FF] text-white rounded-full flex items-center justify-center font-medium">3</div>
                  <p className="text-gray-600">Point your camera at an Untamable-enabled artwork</p>
                </li>
                <li className="flex gap-3">
                  <div className="flex-shrink-0 h-6 w-6 bg-[#6C63FF] text-white rounded-full flex items-center justify-center font-medium">4</div>
                  <p className="text-gray-600">Watch as the artwork comes to life with augmented reality!</p>
                </li>
              </ol>
            </CardContent>
          </Card>

          <h2 className="text-xl font-heading font-bold text-neutral-dark mb-4">Currently Scanning</h2>
          
          {isLoading ? (
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <Skeleton className="h-24 w-24 rounded-lg flex-shrink-0" />
                  <div className="flex-1">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : selectedArtwork ? (
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <img 
                    src={selectedArtwork.imageUrl} 
                    alt={selectedArtwork.title}
                    className="h-24 w-24 object-cover rounded-lg flex-shrink-0"
                  />
                  <div>
                    <h3 className="text-lg font-medium text-neutral-dark">{selectedArtwork.title}</h3>
                    <p className="text-sm text-gray-500 mt-1 line-clamp-2">{selectedArtwork.description || 'No description provided'}</p>
                    <div className="mt-2 flex gap-2">
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#6C63FF]/10 text-[#6C63FF]">
                        {selectedArtwork.contentType === 'video/mp4' ? 'Video' : 
                         selectedArtwork.contentType === 'image/gif' ? 'Animated GIF' : 
                         'Interactive 3D'}
                      </span>
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                        <svg className="h-3 w-3 mr-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                          <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                        </svg>
                        {selectedArtwork.views}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <div className="flex flex-col items-center justify-center text-gray-500">
                  <svg className="h-12 w-12 mb-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7m-14 0l2 2m0 0l7 7-7-7m14 0l-2-2m0 0l-7-7-7 7" />
                  </svg>
                  <p>No artwork is currently being scanned</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
