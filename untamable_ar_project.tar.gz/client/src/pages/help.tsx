import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";

export default function Help() {
  const faqs = [
    {
      question: "What is Untamable?",
      answer: "Untamable is an AR-powered interactive art platform that allows artists to upload 2D artworks (paintings, posters, etc.) and attach digital overlays (animations, 3D models, or videos) that appear when viewed through our mobile app."
    },
    {
      question: "How does the AR technology work?",
      answer: "Our app uses image recognition technology to detect your 2D artwork. When a user scans the artwork through our app, it triggers the display of your linked digital content (animation, video, or 3D model), creating an augmented reality experience."
    },
    {
      question: "What types of AR content can I upload?",
      answer: "Currently, we support MP4 videos, GIF animations, and GLB/GLTF 3D models. The maximum file size is 100MB, but we recommend keeping files under 30MB for optimal performance."
    },
    {
      question: "Do I need special equipment to create AR content?",
      answer: "No special equipment is needed! You can use regular digital art tools to create your content. For videos and animations, standard software like Adobe After Effects or even free tools like GIMP can be used. For 3D models, programs like Blender (free) work great."
    },
    {
      question: "How do users find my AR artwork?",
      answer: "Users can discover AR artworks through the Untamable mobile app's gallery section, or by physically encountering your artwork and scanning it. You can also share a direct link to your artwork on social media."
    },
    {
      question: "Can I see statistics about how many people view my artwork?",
      answer: "Yes! The dashboard provides detailed analytics including total views, unique viewers, average viewing time, and engagement rate for each of your artworks."
    },
    {
      question: "Is there a limit to how many artworks I can upload?",
      answer: "The free tier allows up to 5 AR artworks. Premium accounts can upload unlimited artworks and get access to additional features like higher resolution content and detailed analytics."
    },
    {
      question: "How do I delete an artwork?",
      answer: "You can delete an artwork by clicking on the trash icon in the artwork card on the 'My Artworks' page. This will remove both the artwork and its associated AR content from our platform."
    }
  ];

  return (
    <div>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-neutral-dark">Help Center</h1>
        <p className="mt-2 text-gray-600 max-w-3xl">Find answers to common questions about using Untamable for your AR art experiences.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-heading font-bold text-neutral-dark mb-4">Frequently Asked Questions</h2>
              <Accordion type="single" collapsible className="w-full">
                {faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-gray-600">{faq.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-lg font-heading font-bold text-neutral-dark mb-4">Need More Help?</h2>
              <p className="text-gray-600 mb-4">If you couldn't find the answer to your question, feel free to contact our support team.</p>
              
              <h3 className="font-medium text-neutral-dark mt-6 mb-2">Contact Support</h3>
              <a href="mailto:support@untamable.art" className="text-[#6C63FF] hover:underline block mb-1">support@untamable.art</a>
              
              <h3 className="font-medium text-neutral-dark mt-6 mb-2">Documentation</h3>
              <a href="#" className="text-[#6C63FF] hover:underline block mb-1">Getting Started Guide</a>
              <a href="#" className="text-[#6C63FF] hover:underline block mb-1">AR Content Creation Tips</a>
              <a href="#" className="text-[#6C63FF] hover:underline block mb-1">Mobile App User Guide</a>
              
              <h3 className="font-medium text-neutral-dark mt-6 mb-2">Community</h3>
              <a href="#" className="text-[#6C63FF] hover:underline block mb-1">Untamable Artist Forum</a>
              <a href="#" className="text-[#6C63FF] hover:underline block mb-1">Discord Server</a>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
