import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { loginWithGoogle, useAuth } from '@/lib/firebase';
import { useLocation } from 'wouter';

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const [_, setLocation] = useLocation();

  // Redirect to dashboard if already logged in
  if (user) {
    setLocation('/');
    return null;
  }

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);
      await loginWithGoogle();
      // Redirect happens automatically after successful login due to the useEffect in useAuth
    } catch (error) {
      console.error("Login failed:", error);
      toast({
        title: "Login Failed",
        description: "There was an error logging in with Google. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <svg className="h-12 w-auto text-[#6C63FF]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
              <circle cx="12" cy="8" r="2"></circle>
            </svg>
          </div>
          <CardTitle className="text-2xl font-heading text-neutral-dark">Welcome to Untamable</CardTitle>
          <CardDescription className="mt-2">
            Sign in to create and manage your AR-powered art experiences
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full flex items-center justify-center gap-2"
              onClick={handleGoogleLogin}
              disabled={isLoading}
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.24 10.285V14.4h6.806c-.275 1.765-2.056 5.174-6.806 5.174-4.095 0-7.439-3.389-7.439-7.574s3.345-7.574 7.439-7.574c2.33 0 3.891.989 4.785 1.849l3.254-3.138C18.189 1.186 15.479 0 12.24 0c-6.635 0-12 5.365-12 12s5.365 12 12 12c6.926 0 11.52-4.869 11.52-11.726 0-.788-.085-1.39-.189-1.989H12.24z" fill="currentColor"/>
              </svg>
              {isLoading ? "Signing in..." : "Sign in with Google"}
            </Button>
            
            {/* Add more login options here in the future */}
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-center text-sm text-gray-500">
            By signing in, you agree to our 
            <a href="/terms" className="text-[#6C63FF] hover:underline ml-1">Terms of Service</a> and 
            <a href="/privacy" className="text-[#6C63FF] hover:underline ml-1">Privacy Policy</a>
          </div>
          <div className="text-center text-sm text-gray-500">
            Don't have an account? Sign in to create one automatically.
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
