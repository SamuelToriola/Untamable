import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged,
  signOut,
  User
} from "firebase/auth";
import { 
  getStorage, 
  ref, 
  uploadBytes, 
  getDownloadURL,
  deleteObject 
} from "firebase/storage";
import { useEffect, useState } from "react";
import { apiRequest } from "./queryClient";

// Firebase configuration (using demo mode until credentials are provided)
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyAJ7TLWrRJoGcluCBjLCGbRgwi3oXC-O_o", // Mock key
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project"}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project",
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || "demo-project"}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123456789012:web:a1b2c3d4e5f6g7h8i9j0",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const storage = getStorage(app);
const googleProvider = new GoogleAuthProvider();

// Authentication functions
export const loginWithGoogle = async () => {
  try {
    // Try to use Firebase authentication if available
    try {
      const result = await signInWithPopup(auth, googleProvider);
      // Create or update user in backend
      if (result.user) {
        const { uid, displayName, email, photoURL } = result.user;
        const userData = {
          uid,
          displayName: displayName || "User",
          email: email || `${uid}@example.com`,
          username: email?.split('@')[0] || uid,
          photoURL: photoURL || "",
        };
        await apiRequest('POST', '/api/auth/register', userData);
        return result.user;
      }
    } catch (firebaseError) {
      console.warn("Firebase authentication failed, using demo mode:", firebaseError);
      
      // If Firebase auth fails, use a demo user for testing
      const demoUser = {
        uid: "demo-user-123",
        displayName: "Demo Artist",
        email: "demo@example.com",
        photoURL: "https://ui-avatars.com/api/?name=Demo+Artist&background=random"
      };
      
      // Register the demo user with our backend
      try {
        const userData = {
          uid: demoUser.uid,
          displayName: demoUser.displayName,
          email: demoUser.email,
          username: "demoartist",
          photoURL: demoUser.photoURL,
        };
        await apiRequest('POST', '/api/auth/register', userData);
      } catch (apiError) {
        console.error("Error registering demo user:", apiError);
      }
      
      // Return the demo user as if it came from Firebase
      return demoUser as User;
    }
  } catch (error) {
    console.error("Error signing in:", error);
    throw error;
  }
};

export const logoutUser = () => signOut(auth);

// Custom hook for auth state
export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribe = () => {};
    
    // Try to use Firebase auth if available
    try {
      unsubscribe = onAuthStateChanged(auth, (authUser) => {
        setUser(authUser);
        setLoading(false);
      });
    } catch (error) {
      console.warn("Firebase auth state change failed, using demo mode:", error);
      
      // If no Firebase auth is available, use demo user data after a short delay
      const demoUser = {
        uid: "demo-user-123",
        displayName: "Demo Artist",
        email: "demo@example.com",
        photoURL: "https://ui-avatars.com/api/?name=Demo+Artist&background=random"
      } as User;
      
      // Simulate auth state change after a brief delay
      const timeoutId = setTimeout(() => {
        setUser(demoUser);
        setLoading(false);
      }, 500);
      
      unsubscribe = () => clearTimeout(timeoutId);
    }
    
    return unsubscribe;
  }, []);

  return { user, loading };
};

// File upload functions
export const uploadFile = async (file: File, path: string): Promise<string> => {
  try {
    // Try to use Firebase storage if available
    try {
      const storageRef = ref(storage, path);
      await uploadBytes(storageRef, file);
      return await getDownloadURL(storageRef);
    } catch (firebaseError) {
      console.warn("Firebase storage upload failed, using demo mode:", firebaseError);
      
      // If Firebase storage fails, create a demo URL
      // Create a data URL for images (only works for small images in demo mode)
      if (file.type.startsWith('image/')) {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            resolve(reader.result as string);
          };
          reader.readAsDataURL(file);
        });
      }
      
      // For non-image files, just return a placeholder URL
      return `https://placehold.co/600x400?text=${encodeURIComponent(file.name)}`;
    }
  } catch (error) {
    console.error("Error uploading file:", error);
    throw error;
  }
};

export const deleteFile = async (url: string): Promise<void> => {
  try {
    // Skip deletion for data URLs and placeholder URLs in demo mode
    if (url.startsWith('data:') || url.includes('placehold.co')) {
      console.log("Demo mode: Skipping deletion of", url);
      return;
    }
    
    // Try to use Firebase storage for real URLs
    try {
      // Extract the path from the download URL
      const decodedUrl = decodeURIComponent(url);
      const path = decodedUrl.split('/o/')[1]?.split('?')[0];
      
      if (!path) {
        throw new Error("Could not extract file path from URL");
      }
      
      const fileRef = ref(storage, path);
      await deleteObject(fileRef);
    } catch (firebaseError) {
      console.warn("Firebase storage delete failed, using demo mode:", firebaseError);
      // In demo mode, we just log that we would have deleted the file
      console.log("Demo mode: Would delete file at", url);
    }
  } catch (error) {
    console.error("Error deleting file:", error);
    throw error;
  }
};

export { auth, storage };
