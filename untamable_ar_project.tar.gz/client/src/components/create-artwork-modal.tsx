import { useState, useRef, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { uploadFile } from "@/lib/firebase";
import { useAuth } from "@/lib/firebase";
import { CreateArtwork, Layer } from "@shared/schema";
import { LayersManager } from "./layers-manager";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Layers, ImageIcon, InfoIcon } from "lucide-react";

interface CreateArtworkModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateArtworkModal({ open, onOpenChange }: CreateArtworkModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [activeTab, setActiveTab] = useState("details");
  const [artwork, setArtwork] = useState<Partial<CreateArtwork>>({
    title: "",
    description: "",
    layers: []
  });
  
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Reset form when modal closes
  useEffect(() => {
    if (!open) {
      resetForm();
    }
  }, [open]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setArtwork((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Image must be less than 10MB",
          variant: "destructive",
        });
        return;
      }
      
      // Validate dimensions by loading the image
      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      
      img.onload = () => {
        if (img.width < 500 || img.height < 500) {
          toast({
            title: "Image Too Small",
            description: "Image must be at least 500x500 pixels",
            variant: "destructive",
          });
          URL.revokeObjectURL(objectUrl);
          return;
        }
        
        // Image is valid
        setImageFile(file);
        setImagePreview(objectUrl);
      };
      
      img.onerror = () => {
        toast({
          title: "Invalid Image",
          description: "Selected file is not a valid image",
          variant: "destructive",
        });
        URL.revokeObjectURL(objectUrl);
      };
      
      img.src = objectUrl;
    }
  };

  const resetForm = () => {
    setArtwork({ 
      title: "", 
      description: "",
      layers: [] 
    });
    setImageFile(null);
    setImagePreview(null);
    setActiveTab("details");
    if (imageInputRef.current) imageInputRef.current.value = "";
  };

  const handleLayersChange = (layers: Layer[]) => {
    setArtwork(prev => ({ ...prev, layers }));
  };

  const createArtworkMutation = useMutation({
    mutationFn: async (data: CreateArtwork) => {
      const response = await apiRequest('POST', '/api/artworks', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/artworks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Artwork Created",
        description: "Your artwork has been created successfully.",
      });
      onOpenChange(false);
      resetForm();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create artwork: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user || !imageFile || !artwork.title) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields and upload the trigger image.",
        variant: "destructive",
      });
      return;
    }

    // Validate that at least one layer is added
    if (!artwork.layers || artwork.layers.length === 0) {
      toast({
        title: "No AR Layers",
        description: "Please add at least one AR layer to your artwork.",
        variant: "destructive",
      });
      setActiveTab("layers");
      return;
    }

    try {
      setIsCreating(true);
      
      // Upload files to Firebase Storage
      const userId = user.uid;
      const timestamp = Date.now();
      
      const imageUrl = await uploadFile(
        imageFile, 
        `artworks/${userId}/${timestamp}_image.${imageFile.name.split('.').pop()}`
      );
      
      // Create artwork in backend
      await createArtworkMutation.mutateAsync({
        ...artwork as CreateArtwork,
        imageUrl,
        userId: 0, // This will be set by the backend based on the authenticated user
      });
    } catch (error) {
      console.error("Error creating artwork:", error);
      toast({
        title: "Error",
        description: "There was an error creating your artwork. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const getTabButtonStyles = (tabName: string) => {
    return activeTab === tabName ? 
      "bg-primary text-white" : 
      "bg-gray-100 text-gray-700 hover:bg-gray-200";
  };

  const canProceedToLayers = !!imageFile && !!artwork.title;
  const canSubmit = canProceedToLayers && artwork.layers && artwork.layers.length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-heading font-bold text-neutral-dark">
            Create New AR Artwork
          </DialogTitle>
          <DialogDescription>
            Upload your 2D artwork and add interactive AR layers to bring it to life.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger 
              value="details" 
              className="flex items-center gap-2"
            >
              <InfoIcon className="w-4 h-4" /> Artwork Details
            </TabsTrigger>
            <TabsTrigger 
              value="layers" 
              className="flex items-center gap-2"
              disabled={!canProceedToLayers}
            >
              <Layers className="w-4 h-4" /> AR Layers
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="details" className="space-y-4">
            <form id="artwork-details-form" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Artwork Title</Label>
                    <Input
                      id="title"
                      name="title"
                      value={artwork.title}
                      onChange={handleInputChange}
                      placeholder="Enter a title for your artwork"
                      className="mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={artwork.description || ''}
                      onChange={handleInputChange}
                      placeholder="Describe your artwork and the AR experience"
                      className="mt-1"
                      rows={4}
                    />
                  </div>
                </div>

                <div>
                  <Label>Upload Trigger Image</Label>
                  <div 
                    className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${imageFile ? 'border-primary' : 'border-gray-300'} border-dashed rounded-md cursor-pointer h-[220px]`}
                    onClick={() => imageInputRef.current?.click()}
                  >
                    <div className="space-y-1 text-center self-center">
                      {imagePreview ? (
                        <img 
                          src={imagePreview} 
                          alt="Artwork preview" 
                          className="mx-auto h-32 w-auto object-contain"
                        />
                      ) : (
                        <ImageIcon 
                          className={`mx-auto h-12 w-12 ${imageFile ? 'text-primary' : 'text-gray-400'}`}
                        />
                      )}
                      <div className="flex justify-center text-sm text-gray-600">
                        <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                          <span>{imageFile ? 'Change image' : 'Upload trigger image'}</span>
                          <input
                            ref={imageInputRef}
                            id="trigger-image-upload"
                            name="trigger-image-upload"
                            type="file"
                            className="sr-only"
                            accept="image/*"
                            onChange={handleImageFileChange}
                          />
                        </label>
                      </div>
                      <p className="text-xs text-gray-500">
                        PNG, JPG, WEBP (min. 500x500px, max 10MB)
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end pt-2">
                <Button 
                  type="button" 
                  onClick={() => setActiveTab("layers")} 
                  disabled={!canProceedToLayers}
                >
                  Continue to AR Layers
                </Button>
              </div>
            </form>
          </TabsContent>
          
          <TabsContent value="layers">
            <div className="space-y-6">
              <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
                <h3 className="text-sm font-medium text-yellow-800 mb-1">Adding AR Layers</h3>
                <p className="text-sm text-yellow-700">
                  Add different types of layers to enhance your artwork. When users scan your artwork with the mobile app, these layers will appear overlaid on top.
                </p>
              </div>
              
              {user && (
                <LayersManager 
                  userId={user.uid}
                  initialLayers={artwork.layers || []}
                  onLayersChange={handleLayersChange}
                />
              )}
              
              <div className="flex justify-between pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setActiveTab("details")}
                >
                  Back to Details
                </Button>
                <Button 
                  type="button" 
                  onClick={handleSubmit} 
                  disabled={isCreating || !canSubmit}
                >
                  {isCreating ? "Creating..." : "Create Artwork"}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-2">
          <Button 
            variant="outline" 
            onClick={() => {
              onOpenChange(false);
            }}
            type="button"
          >
            Cancel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
