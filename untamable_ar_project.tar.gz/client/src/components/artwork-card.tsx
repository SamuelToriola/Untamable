import { useState } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { 
  Artwork, 
  Layer, 
  LayerType 
} from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { deleteFile } from "@/lib/firebase";
import { 
  Layers, 
  Eye, 
  Edit, 
  Trash2, 
  ChevronDown, 
  ChevronUp,
  Image as ImageIcon,
  Video, 
  Music, 
  Type as TextIcon, 
  Box, 
  Sparkles
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
  AlertDialogCancel,
  AlertDialogAction
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";

interface ArtworkCardProps {
  artwork: Artwork;
}

export function ArtworkCard({ artwork }: ArtworkCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showLayers, setShowLayers] = useState(false);
  
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/artworks/${artwork.id}`);
      // Delete files from Firebase Storage
      await deleteFile(artwork.imageUrl);
      
      // Delete all layer files
      if (artwork.layers && Array.isArray(artwork.layers) && artwork.layers.length > 0) {
        for (const layer of artwork.layers) {
          if (layer.url) {
            await deleteFile(layer.url);
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/artworks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      toast({
        title: "Artwork Deleted",
        description: "Your artwork has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete artwork: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const getLayerTypeIcon = (type: LayerType) => {
    switch (type) {
      case 'image':
        return <ImageIcon className="h-3 w-3" />;
      case 'video':
        return <Video className="h-3 w-3" />;
      case 'model3d':
        return <Box className="h-3 w-3" />;
      case 'audio':
        return <Music className="h-3 w-3" />;
      case 'text':
        return <TextIcon className="h-3 w-3" />;
      case 'effect':
        return <Sparkles className="h-3 w-3" />;
      case 'group':
        return <Layers className="h-3 w-3" />;
      default:
        return <ImageIcon className="h-3 w-3" />;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 3600 * 24));
    
    if (diffInDays === 0) {
      return "Added today";
    } else if (diffInDays === 1) {
      return "Added yesterday";
    } else if (diffInDays < 7) {
      return `Added ${diffInDays} days ago`;
    } else if (diffInDays < 30) {
      const weeks = Math.floor(diffInDays / 7);
      return `Added ${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
    } else {
      return `Added on ${date.toLocaleDateString()}`;
    }
  };

  return (
    <Card className="overflow-hidden shadow">
      <div className="relative pb-[66.66%] bg-gray-100">
        <img 
          src={artwork.imageUrl} 
          alt={artwork.title} 
          className="absolute h-full w-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-primary text-white text-xs font-medium rounded-full px-2 py-1 flex items-center">
          <Eye className="h-3 w-3 mr-1" />
          {artwork.views}
        </div>
        
        {artwork.layers && Array.isArray(artwork.layers) && artwork.layers.length > 0 && (
          <div className="absolute bottom-2 left-2">
            <Badge variant="secondary" className="bg-white/80 text-black border-0">
              <Layers className="h-3 w-3 mr-1" />
              {artwork.layers.length} AR {artwork.layers.length === 1 ? 'Layer' : 'Layers'}
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <h3 className="text-lg font-medium text-neutral-dark">{artwork.title}</h3>
        <p className="text-sm text-gray-500 mt-1 line-clamp-2">{artwork.description || 'No description provided'}</p>
        
        {artwork.layers && Array.isArray(artwork.layers) && artwork.layers.length > 0 && (
          <div className="mt-3">
            <button 
              className="text-sm text-primary flex items-center font-medium"
              onClick={() => setShowLayers(!showLayers)}
            >
              {showLayers ? <ChevronUp className="h-4 w-4 mr-1" /> : <ChevronDown className="h-4 w-4 mr-1" />}
              {showLayers ? 'Hide AR Layers' : 'Show AR Layers'}
            </button>
            
            {showLayers && (
              <div className="mt-2 space-y-2 bg-gray-50 p-2 rounded-md">
                {artwork.layers.map((layer: Layer, index: number) => (
                  <div key={layer.id || index} className="flex items-center text-xs p-1.5 bg-white rounded shadow-sm">
                    <div className="flex-shrink-0 h-5 w-5 mr-2 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                      {getLayerTypeIcon(layer.type)}
                    </div>
                    <div className="flex-1 truncate">
                      <span className="font-medium">{layer.name}</span>
                      {layer.type === 'text' && layer.content && (
                        <span className="ml-1 text-gray-500 italic">"{layer.content.substring(0, 15)}{layer.content.length > 15 ? '...' : ''}"</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
      
      <CardFooter className="px-4 py-3 bg-gray-50 flex justify-between items-center">
        <span className="text-xs text-gray-500">{typeof artwork.createdAt === 'string' ? formatDate(artwork.createdAt) : 'Recently added'}</span>
        <div className="flex space-x-2">
          <Button 
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-gray-500 hover:text-primary"
            aria-label="Edit artwork"
            // Edit functionality would be implemented in a more complete version
          >
            <Edit className="h-4 w-4" />
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-gray-500 hover:text-red-500"
                aria-label="Delete artwork"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Artwork</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete "{artwork.title}"? This action cannot be undone and all AR layers will be permanently removed.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={() => deleteMutation.mutate()}
                  disabled={deleteMutation.isPending}
                  className="bg-red-500 hover:bg-red-700"
                >
                  {deleteMutation.isPending ? "Deleting..." : "Delete"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </CardFooter>
    </Card>
  );
}
