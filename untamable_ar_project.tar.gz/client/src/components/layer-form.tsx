import { useState, useRef, ChangeEvent } from "react";
import { Layer, LayerType, layerTypes } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { uploadFile } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import { v4 as uuidv4 } from 'uuid';

interface LayerFormProps {
  artworkId?: number;
  userId: string;
  onLayerCreated: (layer: Layer) => void;
  existingLayer?: Layer;
}

export function LayerForm({ artworkId, userId, onLayerCreated, existingLayer }: LayerFormProps) {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [layer, setLayer] = useState<Partial<Layer>>(
    existingLayer || {
      id: uuidv4(),
      type: "image" as LayerType,
      name: "",
      order: 0,
    }
  );
  
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(
    existingLayer?.url || null
  );
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setLayer(prev => ({ ...prev, [name]: value }));
  };

  const handleTypeChange = (type: LayerType) => {
    setLayer(prev => ({ ...prev, type }));
    // Reset file and preview when type changes
    if (fileInputRef.current) fileInputRef.current.value = "";
    setFile(null);
    setPreview(null);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Create preview for image types
      if (selectedFile.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setPreview(event.target?.result as string);
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setPreview(null);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsUploading(true);
      
      if (!layer.name) {
        toast({
          title: "Error",
          description: "Please provide a name for the layer",
          variant: "destructive",
        });
        return;
      }
      
      let finalLayer: Layer = {
        ...layer as Layer
      };
      
      // Handle file upload for layer types that need it
      if (file && ['image', 'video', 'model3d', 'audio'].includes(layer.type as string)) {
        const timestamp = Date.now();
        const filePath = `layers/${userId}/${artworkId || 'new'}/${timestamp}_${layer.type}_${file.name}`;
        
        const url = await uploadFile(file, filePath);
        finalLayer.url = url;
      }
      
      onLayerCreated(finalLayer);
      
      // Reset form for a new layer if it's a new layer being created
      if (!existingLayer) {
        setLayer({
          id: uuidv4(),
          type: "image" as LayerType,
          name: "",
          order: (layer.order || 0) + 1,
        });
        setFile(null);
        setPreview(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
      }
      
      toast({
        title: "Success",
        description: `Layer ${existingLayer ? 'updated' : 'added'} successfully!`,
      });
    } catch (error) {
      console.error("Error creating layer:", error);
      toast({
        title: "Error",
        description: `Failed to ${existingLayer ? 'update' : 'add'} layer. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Determine which input fields to show based on layer type
  const renderLayerTypeInputs = () => {
    switch (layer.type) {
      case 'image':
        return (
          <div className="mb-4">
            <Label htmlFor="image-upload">Image File</Label>
            <div 
              className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 ${file || preview ? 'border-primary' : 'border-gray-300'} border-dashed rounded-md cursor-pointer`}
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="space-y-1 text-center">
                {preview ? (
                  <img 
                    src={preview} 
                    alt="Layer preview" 
                    className="mx-auto h-32 w-auto object-contain"
                  />
                ) : (
                  <svg 
                    className="mx-auto h-12 w-12 text-gray-400" 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                )}
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                    <span>{preview ? 'Change image' : 'Upload image'}</span>
                    <input
                      ref={fileInputRef}
                      id="image-upload"
                      name="image-upload"
                      type="file"
                      className="sr-only"
                      accept="image/*"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
              </div>
            </div>
          </div>
        );
        
      case 'video':
        return (
          <div className="mb-4">
            <Label htmlFor="video-upload">Video File</Label>
            <div 
              className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="space-y-1 text-center">
                <svg 
                  className="mx-auto h-12 w-12 text-gray-400" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                    <span>{file ? file.name : 'Upload video'}</span>
                    <input
                      ref={fileInputRef}
                      id="video-upload"
                      name="video-upload"
                      type="file"
                      className="sr-only"
                      accept="video/mp4,video/webm"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                <p className="text-xs text-gray-500">MP4, WebM up to 100MB</p>
              </div>
            </div>
          </div>
        );
        
      case 'model3d':
        return (
          <div className="mb-4">
            <Label htmlFor="model-upload">3D Model</Label>
            <div 
              className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="space-y-1 text-center">
                <svg 
                  className="mx-auto h-12 w-12 text-gray-400" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
                </svg>
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                    <span>{file ? file.name : 'Upload 3D model'}</span>
                    <input
                      ref={fileInputRef}
                      id="model-upload"
                      name="model-upload"
                      type="file"
                      className="sr-only"
                      accept=".glb,.gltf"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                <p className="text-xs text-gray-500">GLB, GLTF up to 50MB</p>
              </div>
            </div>
          </div>
        );
        
      case 'audio':
        return (
          <div className="mb-4">
            <Label htmlFor="audio-upload">Audio File</Label>
            <div 
              className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="space-y-1 text-center">
                <svg 
                  className="mx-auto h-12 w-12 text-gray-400" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                </svg>
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-dark focus-within:outline-none">
                    <span>{file ? file.name : 'Upload audio'}</span>
                    <input
                      ref={fileInputRef}
                      id="audio-upload"
                      name="audio-upload"
                      type="file"
                      className="sr-only"
                      accept="audio/mp3,audio/wav,audio/mpeg"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
                <p className="text-xs text-gray-500">MP3, WAV up to 20MB</p>
              </div>
            </div>
          </div>
        );
        
      case 'text':
        return (
          <div className="mb-4">
            <Label htmlFor="content">Text Content</Label>
            <Textarea
              id="content"
              name="content"
              value={layer.content || ''}
              onChange={handleInputChange}
              placeholder="Enter text to display"
              className="mt-1"
              rows={4}
            />
          </div>
        );
        
      case 'effect':
        return (
          <div className="mb-4">
            <Label htmlFor="content">Effect Configuration</Label>
            <Textarea
              id="content"
              name="content"
              value={layer.content || ''}
              onChange={handleInputChange}
              placeholder="Enter effect configuration (JSON)"
              className="mt-1"
              rows={4}
            />
            <p className="text-xs text-gray-500 mt-1">
              Examples: {"{ \"type\": \"pixelate\", \"strength\": 5 }"} or {"{ \"type\": \"glow\", \"color\": \"#ff0000\", \"intensity\": 0.8 }"}
            </p>
          </div>
        );
        
      case 'group':
        return (
          <div className="mb-4">
            <Label htmlFor="content">Group Configuration</Label>
            <Textarea
              id="content"
              name="content"
              value={layer.content || ''}
              onChange={handleInputChange}
              placeholder="Enter group configuration (JSON)"
              className="mt-1"
              rows={4}
            />
            <p className="text-xs text-gray-500 mt-1">
              Example: {"{ \"childLayers\": [1, 2, 3], \"playTogether\": true }"}
            </p>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="name">Layer Name</Label>
          <Input
            id="name"
            name="name"
            value={layer.name}
            onChange={handleInputChange}
            placeholder="Enter layer name"
            className="mt-1"
            required
          />
        </div>
        
        <div>
          <Label htmlFor="type">Layer Type</Label>
          <Select 
            value={layer.type} 
            onValueChange={(value: LayerType) => handleTypeChange(value)}
          >
            <SelectTrigger id="type" className="mt-1">
              <SelectValue placeholder="Select layer type" />
            </SelectTrigger>
            <SelectContent>
              {layerTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {renderLayerTypeInputs()}
      
      <div className="flex justify-end">
        <Button
          type="submit"
          disabled={isUploading}
        >
          {isUploading ? "Saving..." : existingLayer ? "Update Layer" : "Add Layer"}
        </Button>
      </div>
    </form>
  );
}