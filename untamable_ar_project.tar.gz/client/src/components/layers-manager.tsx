import { useState, useEffect } from "react";
import { Layer } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LayerForm } from "./layer-form";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import { ChevronDown, ChevronUp, X, Edit, Eye, EyeOff } from "lucide-react";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";

interface LayersManagerProps {
  artworkId?: number; // Undefined for new artworks
  userId: string;
  initialLayers?: Layer[];
  onLayersChange?: (layers: Layer[]) => void;
}

export function LayersManager({ artworkId, userId, initialLayers = [], onLayersChange }: LayersManagerProps) {
  const { toast } = useToast();
  const [layers, setLayers] = useState<Layer[]>(initialLayers);
  const [editingLayerIndex, setEditingLayerIndex] = useState<number | null>(null);
  const [addingLayer, setAddingLayer] = useState(false);
  const [hiddenLayers, setHiddenLayers] = useState<Set<string>>(new Set());

  // Send updates to parent when layers change
  useEffect(() => {
    if (onLayersChange) {
      onLayersChange(layers);
    }
  }, [layers, onLayersChange]);

  // Update layers from API when artworkId changes
  useEffect(() => {
    if (artworkId) {
      const fetchLayers = async () => {
        try {
          const response = await apiRequest('GET', `/api/artworks/${artworkId}/layers`);
          const fetchedLayers = await response.json();
          setLayers(fetchedLayers);
        } catch (error) {
          console.error("Error fetching layers:", error);
          toast({
            title: "Error",
            description: "Failed to load layers. Please refresh the page.",
            variant: "destructive",
          });
        }
      };

      fetchLayers();
    }
  }, [artworkId, toast]);

  // API mutation for updating layers
  const updateLayersMutation = useMutation({
    mutationFn: async (layers: Layer[]) => {
      if (!artworkId) return layers;
      
      const response = await apiRequest(
        'PUT', 
        `/api/artworks/${artworkId}/layers`,
        layers.map((layer, index) => ({
          ...layer,
          order: index // Ensure order matches array index
        }))
      );
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Layers updated successfully!",
      });
    },
    onError: (error) => {
      console.error("Error updating layers:", error);
      toast({
        title: "Error",
        description: "Failed to update layers. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Handle reordering layers with drag and drop
  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const reorderedLayers = Array.from(layers);
    const [movedLayer] = reorderedLayers.splice(result.source.index, 1);
    reorderedLayers.splice(result.destination.index, 0, movedLayer);
    
    // Update order property to match new positions
    const updatedLayers = reorderedLayers.map((layer, index) => ({
      ...layer,
      order: index
    }));
    
    setLayers(updatedLayers);
    
    // Save changes to API if we have an artwork ID
    if (artworkId) {
      updateLayersMutation.mutate(updatedLayers);
    }
  };

  // Handle adding a new layer
  const handleLayerCreated = (newLayer: Layer) => {
    setLayers(current => {
      const updatedLayers = [...current, newLayer];
      return updatedLayers.map((layer, index) => ({
        ...layer,
        order: index
      }));
    });
    
    setAddingLayer(false);
    
    // Save changes to API if we have an artwork ID
    if (artworkId) {
      updateLayersMutation.mutate([...layers, newLayer]);
    }
  };

  // Handle updating an existing layer
  const handleLayerUpdated = (updatedLayer: Layer) => {
    if (editingLayerIndex === null) return;
    
    setLayers(current => {
      const updatedLayers = [...current];
      updatedLayers[editingLayerIndex] = updatedLayer;
      return updatedLayers;
    });
    
    setEditingLayerIndex(null);
    
    // Save changes to API if we have an artwork ID
    if (artworkId) {
      updateLayersMutation.mutate([...layers]);
    }
  };

  // Handle deleting a layer
  const handleDeleteLayer = (layerId: string) => {
    setLayers(current => current.filter(layer => layer.id !== layerId));
    
    // Save changes to API if we have an artwork ID
    if (artworkId) {
      updateLayersMutation.mutate(layers.filter(layer => layer.id !== layerId));
    }
  };

  // Handle toggling layer visibility
  const toggleLayerVisibility = (layerId: string) => {
    setHiddenLayers(current => {
      const updated = new Set(current);
      if (updated.has(layerId)) {
        updated.delete(layerId);
      } else {
        updated.add(layerId);
      }
      return updated;
    });
  };

  // Get layer type display name
  const getLayerTypeDisplay = (type: string): string => {
    return type.charAt(0).toUpperCase() + type.slice(1).replace(/([A-Z])/g, ' $1');
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">AR Layers</h3>
        <Button 
          onClick={() => setAddingLayer(true)}
          size="sm"
        >
          Add Layer
        </Button>
      </div>

      {layers.length === 0 && !addingLayer ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-500 mb-3">No layers added yet</p>
            <Button onClick={() => setAddingLayer(true)}>
              Add Your First Layer
            </Button>
          </CardContent>
        </Card>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="layers">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="space-y-2"
              >
                {layers.map((layer, index) => (
                  <Draggable key={layer.id} draggableId={layer.id || `layer-${index}`} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className="relative"
                      >
                        <Card className={`${hiddenLayers.has(layer.id || '') ? 'opacity-60' : ''}`}>
                          <CardHeader className="p-3 pb-0 flex-row flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 w-6 h-6 mr-2 rounded-full bg-primary text-white flex items-center justify-center">
                                {index + 1}
                              </div>
                              <CardTitle className="text-base">{layer.name}</CardTitle>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => toggleLayerVisibility(layer.id || '')}
                                title={hiddenLayers.has(layer.id || '') ? "Show layer" : "Hide layer"}
                              >
                                {hiddenLayers.has(layer.id || '') ? <EyeOff size={16} /> : <Eye size={16} />}
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => setEditingLayerIndex(index)}
                                title="Edit layer"
                              >
                                <Edit size={16} />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-50"
                                    title="Delete layer"
                                  >
                                    <X size={16} />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Layer</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete this layer? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction 
                                      className="bg-red-500 hover:bg-red-700"
                                      onClick={() => handleDeleteLayer(layer.id || '')}
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </CardHeader>
                          <CardContent className="p-3 pt-0">
                            <div className="text-xs text-gray-500">
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 mr-2">
                                {getLayerTypeDisplay(layer.type)}
                              </span>
                              {layer.url && (
                                <span className="truncate block sm:inline-block mt-1 sm:mt-0">
                                  {layer.url.split('/').pop()}
                                </span>
                              )}
                              {layer.content && !layer.url && (
                                <span className="truncate block sm:inline-block mt-1 sm:mt-0">
                                  {layer.content.length > 30 
                                    ? layer.content.slice(0, 30) + '...' 
                                    : layer.content}
                                </span>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}

      {/* Layer Form Dialog */}
      <AlertDialog 
        open={addingLayer || editingLayerIndex !== null} 
        onOpenChange={(open) => {
          if (!open) {
            setAddingLayer(false);
            setEditingLayerIndex(null);
          }
        }}
      >
        <AlertDialogContent className="max-w-3xl">
          <AlertDialogHeader>
            <AlertDialogTitle>
              {editingLayerIndex !== null ? "Edit Layer" : "Add New Layer"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {editingLayerIndex !== null 
                ? "Update the properties of this AR layer." 
                : "Add a new layer to enhance your AR experience."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <LayerForm 
            artworkId={artworkId}
            userId={userId}
            onLayerCreated={editingLayerIndex !== null ? handleLayerUpdated : handleLayerCreated}
            existingLayer={editingLayerIndex !== null ? layers[editingLayerIndex] : undefined}
          />
          
          <AlertDialogFooter className="mt-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}