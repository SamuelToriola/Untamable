import { Link } from 'wouter';

export function Footer() {
  return (
    <footer className="bg-white">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex flex-col items-center sm:flex-row sm:justify-between">
        <div className="flex items-center">
          <svg className="h-6 w-auto text-[#6C63FF]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            <circle cx="12" cy="8" r="2"></circle>
          </svg>
          <span className="ml-2 text-sm text-gray-500">© {new Date().getFullYear()} Untamable. All rights reserved.</span>
        </div>
        <div className="mt-4 sm:mt-0">
          <nav className="flex space-x-6">
            <Link href="/privacy">
              <a className="text-sm text-gray-500 hover:text-gray-700">Privacy</a>
            </Link>
            <Link href="/terms">
              <a className="text-sm text-gray-500 hover:text-gray-700">Terms</a>
            </Link>
            <Link href="/help">
              <a className="text-sm text-gray-500 hover:text-gray-700">Help</a>
            </Link>
            <Link href="/contact">
              <a className="text-sm text-gray-500 hover:text-gray-700">Contact</a>
            </Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}
