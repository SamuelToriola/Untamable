import { ReactNode } from 'react';

interface MobilePreviewProps {
  children?: ReactNode;
  title: string;
  description: string;
}

export function MobilePreview({ 
  children, 
  title, 
  description 
}: MobilePreviewProps) {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="w-full max-w-md bg-neutral-dark rounded-3xl overflow-hidden shadow-2xl border-8 border-black">
        <div className="relative bg-black pt-6">
          {/* Status bar */}
          <div className="flex justify-between items-center px-4 text-white text-xs pb-2">
            <span>9:41</span>
            <div className="flex items-center space-x-1">
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 20.5a8.5 8.5 0 100-17 8.5 8.5 0 000 17z"></path>
              </svg>
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 20.5a8.5 8.5 0 100-17 8.5 8.5 0 000 17z"></path>
              </svg>
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 20.5a8.5 8.5 0 100-17 8.5 8.5 0 000 17z"></path>
              </svg>
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 20.5a8.5 8.5 0 100-17 8.5 8.5 0 000 17z"></path>
              </svg>
            </div>
          </div>

          {/* Content View */}
          <div className="relative pb-[177.78%]">
            {children ? (
              children
            ) : (
              <>
                {/* Default Camera view */}
                <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
                  <svg className="h-24 w-24 text-gray-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
              </>
            )}

            {/* AR controls */}
            <div className="absolute bottom-8 left-0 right-0 flex justify-center space-x-6">
              <button className="bg-white bg-opacity-30 backdrop-blur-sm p-3 rounded-full">
                <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </button>
              <button className="bg-white bg-opacity-30 backdrop-blur-sm p-3 rounded-full">
                <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </button>
              <button className="bg-white bg-opacity-30 backdrop-blur-sm p-3 rounded-full">
                <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                </svg>
              </button>
            </div>
          </div>

          {/* Bottom navigation bar */}
          <div className="bg-black text-white py-4 px-6 flex justify-around">
            <button className="flex flex-col items-center">
              <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7m-14 0l2 2m0 0l7 7-7-7m14 0l-2-2m0 0l-7-7-7 7" />
              </svg>
              <span className="text-xs mt-1">Scan</span>
            </button>
            <button className="flex flex-col items-center">
              <svg className="h-6 w-6 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
              <span className="text-xs mt-1 text-gray-500">Gallery</span>
            </button>
            <button className="flex flex-col items-center">
              <svg className="h-6 w-6 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <span className="text-xs mt-1 text-gray-500">Profile</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-12 text-center">
        <h3 className="text-lg font-medium text-neutral-dark">{title}</h3>
        <p className="mt-2 text-sm text-gray-500 max-w-md">{description}</p>
      </div>
    </div>
  );
}

export function ARScannerView() {
  return (
    <MobilePreview
      title="AR Scanner Preview"
      description="This is how the AR scanner will look in the mobile app. Users will point their camera at your artwork to see the AR experience come to life."
    >
      {/* Camera view */}
      <div className="absolute inset-0 bg-gray-900">
        {/* Default overlay for AR scanner */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="w-3/4 h-3/4 border-2 border-white rounded-lg opacity-70 flex items-center justify-center">
            <div className="animate-pulse text-white text-xl font-bold">Scanning...</div>
          </div>
        </div>
      </div>
    </MobilePreview>
  );
}
