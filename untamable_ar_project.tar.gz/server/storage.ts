import { 
  users, artworks, 
  type User, type InsertUser, 
  type Artwork, type InsertArtwork,
  type UserStats, type Layer
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUid(uid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Artwork operations
  getArtworks(userId?: number): Promise<Artwork[]>;
  getRecentArtworks(userId: number, limit?: number): Promise<Artwork[]>;
  getArtwork(id: number): Promise<Artwork | undefined>;
  createArtwork(artwork: InsertArtwork): Promise<Artwork>;
  updateArtwork(id: number, artwork: Partial<InsertArtwork>): Promise<Artwork | undefined>;
  updateArtworkLayers(id: number, layers: Layer[]): Promise<Artwork | undefined>;
  deleteArtwork(id: number): Promise<boolean>;
  incrementArtworkViews(id: number): Promise<boolean>;
  
  // Stats operations
  getUserStats(userId: number): Promise<UserStats>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private artworks: Map<number, Artwork>;
  private currentUserId: number;
  private currentArtworkId: number;

  constructor() {
    this.users = new Map();
    this.artworks = new Map();
    this.currentUserId = 1;
    this.currentArtworkId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUid(uid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.uid === uid);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const existingUser = await this.getUserByUid(insertUser.uid);
    if (existingUser) {
      return existingUser;
    }
    
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: now.toISOString() 
    };
    this.users.set(id, user);
    return user;
  }

  // Artwork operations
  async getArtworks(userId?: number): Promise<Artwork[]> {
    const allArtworks = Array.from(this.artworks.values());
    return userId 
      ? allArtworks.filter(artwork => artwork.userId === userId)
      : allArtworks;
  }

  async getRecentArtworks(userId: number, limit: number = 3): Promise<Artwork[]> {
    const userArtworks = await this.getArtworks(userId);
    return userArtworks
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async getArtwork(id: number): Promise<Artwork | undefined> {
    return this.artworks.get(id);
  }

  async createArtwork(insertArtwork: InsertArtwork): Promise<Artwork> {
    const id = this.currentArtworkId++;
    const now = new Date();
    
    // Ensure layers is always an array
    const layers = insertArtwork.layers || [];
    
    const artwork: Artwork = { 
      ...insertArtwork, 
      layers, 
      id, 
      views: 0, 
      createdAt: now.toISOString() 
    };
    
    this.artworks.set(id, artwork);
    return artwork;
  }

  async updateArtwork(id: number, partialArtwork: Partial<InsertArtwork>): Promise<Artwork | undefined> {
    const artwork = await this.getArtwork(id);
    if (!artwork) return undefined;

    const updatedArtwork: Artwork = { ...artwork, ...partialArtwork };
    this.artworks.set(id, updatedArtwork);
    return updatedArtwork;
  }

  async updateArtworkLayers(id: number, layers: Layer[]): Promise<Artwork | undefined> {
    const artwork = await this.getArtwork(id);
    if (!artwork) return undefined;

    const updatedArtwork: Artwork = { ...artwork, layers };
    this.artworks.set(id, updatedArtwork);
    return updatedArtwork;
  }

  async deleteArtwork(id: number): Promise<boolean> {
    return this.artworks.delete(id);
  }

  async incrementArtworkViews(id: number): Promise<boolean> {
    const artwork = await this.getArtwork(id);
    if (!artwork) return false;

    artwork.views += 1;
    this.artworks.set(id, artwork);
    return true;
  }

  // Stats operations
  async getUserStats(userId: number): Promise<UserStats> {
    const userArtworks = await this.getArtworks(userId);
    
    // Calculate stats
    const totalArtworks = userArtworks.length;
    const totalViews = userArtworks.reduce((sum, artwork) => sum + artwork.views, 0);
    
    // Calculate engagement rate (views per artwork, represented as a percentage of a baseline of 100 views)
    let engagementRate = "0%";
    if (totalArtworks > 0) {
      const viewsPerArtwork = totalViews / totalArtworks;
      const rate = Math.min(100, Math.round((viewsPerArtwork / 100) * 100));
      engagementRate = `${rate}%`;
    }

    return {
      totalArtworks,
      totalViews,
      engagementRate
    };
  }
}

export const storage = new MemStorage();
