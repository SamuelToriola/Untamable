import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertArtworkSchema, 
  createArtworkSchema,
  layerSchema
} from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { Layer } from "@shared/schema";

// Middleware to check user authentication
const authenticateUser = async (req: Request, res: Response, next: Function) => {
  // For a real implementation, we would validate a JWT or session token
  // For this demo, we'll check for a user ID in request headers
  
  // In a production app, Firebase SDK would be used on the server to verify the token
  const firebaseUid = req.headers['x-firebase-uid'] as string;
  
  if (!firebaseUid) {
    return res.status(401).json({ message: "Unauthorized. Please log in." });
  }
  
  try {
    // Get the user by Firebase UID
    const user = await storage.getUserByUid(firebaseUid);
    
    if (!user) {
      return res.status(401).json({ message: "User not found. Please register first." });
    }
    
    // Attach user to the request
    req.user = user;
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    res.status(500).json({ message: "Authentication error" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Type declaration for authenticated requests
  app.use((req, _, next) => {
    req.user = undefined;
    next();
  });

  // AUTH ROUTES
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: fromZodError(error).message 
        });
      }
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Error creating user" });
    }
  });

  // ARTWORK ROUTES
  // Get all artworks for the authenticated user
  app.get('/api/artworks', authenticateUser, async (req, res) => {
    try {
      const artworks = await storage.getArtworks(req.user!.id);
      res.json(artworks);
    } catch (error) {
      console.error("Error fetching artworks:", error);
      res.status(500).json({ message: "Error fetching artworks" });
    }
  });

  // Get recent artworks for the authenticated user
  app.get('/api/artworks/recent', authenticateUser, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 3;
      const artworks = await storage.getRecentArtworks(req.user!.id, limit);
      res.json(artworks);
    } catch (error) {
      console.error("Error fetching recent artworks:", error);
      res.status(500).json({ message: "Error fetching recent artworks" });
    }
  });

  // Get a single artwork
  app.get('/api/artworks/:id', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to access this artwork" });
      }
      
      res.json(artwork);
    } catch (error) {
      console.error("Error fetching artwork:", error);
      res.status(500).json({ message: "Error fetching artwork" });
    }
  });

  // Create a new artwork
  app.post('/api/artworks', authenticateUser, async (req, res) => {
    try {
      const artworkData = createArtworkSchema.parse(req.body);
      // Override userId with the authenticated user's ID
      const artwork = await storage.createArtwork({
        ...artworkData,
        userId: req.user!.id
      });
      res.status(201).json(artwork);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid artwork data", 
          errors: fromZodError(error).message 
        });
      }
      console.error("Error creating artwork:", error);
      res.status(500).json({ message: "Error creating artwork" });
    }
  });

  // Update an artwork
  app.patch('/api/artworks/:id', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to update this artwork" });
      }
      
      const updateSchema = insertArtworkSchema.partial();
      const artworkData = updateSchema.parse(req.body);
      
      const updatedArtwork = await storage.updateArtwork(id, artworkData);
      res.json(updatedArtwork);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid artwork data", 
          errors: fromZodError(error).message 
        });
      }
      console.error("Error updating artwork:", error);
      res.status(500).json({ message: "Error updating artwork" });
    }
  });

  // Delete an artwork
  app.delete('/api/artworks/:id', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to delete this artwork" });
      }
      
      await storage.deleteArtwork(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting artwork:", error);
      res.status(500).json({ message: "Error deleting artwork" });
    }
  });

  // Record a view of an artwork
  app.post('/api/artworks/:id/view', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.incrementArtworkViews(id);
      
      if (!success) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error recording artwork view:", error);
      res.status(500).json({ message: "Error recording artwork view" });
    }
  });

  // Add new routes for layers
  
  // Get all layers for an artwork
  app.get('/api/artworks/:id/layers', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to access this artwork's layers" });
      }
      
      res.json(artwork.layers || []);
    } catch (error) {
      console.error("Error fetching layers:", error);
      res.status(500).json({ message: "Error fetching layers" });
    }
  });
  
  // Update layers for an artwork
  app.put('/api/artworks/:id/layers', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to update this artwork's layers" });
      }
      
      const layersSchema = z.array(layerSchema);
      const layers = layersSchema.parse(req.body);
      
      const updatedArtwork = await storage.updateArtworkLayers(id, layers);
      
      res.json(updatedArtwork?.layers || []);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid layer data", 
          errors: fromZodError(error).message 
        });
      }
      console.error("Error updating layers:", error);
      res.status(500).json({ message: "Error updating layers" });
    }
  });
  
  // Add a single layer to an artwork
  app.post('/api/artworks/:id/layers', authenticateUser, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const artwork = await storage.getArtwork(id);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to add layers to this artwork" });
      }
      
      const layer = layerSchema.parse(req.body);
      const currentLayers = Array.isArray(artwork.layers) ? artwork.layers : [];
      
      // Assign an order if not provided
      if (layer.order === undefined) {
        layer.order = currentLayers.length;
      }
      
      // Generate UUID if not provided
      if (!layer.id) {
        layer.id = crypto.randomUUID();
      }
      
      const updatedLayers = [...currentLayers, layer];
      const updatedArtwork = await storage.updateArtworkLayers(id, updatedLayers);
      
      res.status(201).json(layer);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid layer data", 
          errors: fromZodError(error).message 
        });
      }
      console.error("Error adding layer:", error);
      res.status(500).json({ message: "Error adding layer" });
    }
  });
  
  // Delete a layer
  app.delete('/api/artworks/:artworkId/layers/:layerId', authenticateUser, async (req, res) => {
    try {
      const artworkId = parseInt(req.params.artworkId);
      const layerId = req.params.layerId;
      const artwork = await storage.getArtwork(artworkId);
      
      if (!artwork) {
        return res.status(404).json({ message: "Artwork not found" });
      }
      
      // Check if the artwork belongs to the authenticated user
      if (artwork.userId !== req.user!.id) {
        return res.status(403).json({ message: "You do not have permission to delete layers from this artwork" });
      }
      
      const currentLayers = Array.isArray(artwork.layers) ? artwork.layers : [];
      const updatedLayers = currentLayers.filter((layer: any) => layer.id !== layerId);
      
      // If no layer was removed, it wasn't found
      if (updatedLayers.length === currentLayers.length) {
        return res.status(404).json({ message: "Layer not found" });
      }
      
      await storage.updateArtworkLayers(artworkId, updatedLayers);
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting layer:", error);
      res.status(500).json({ message: "Error deleting layer" });
    }
  });

  // Get user stats
  app.get('/api/stats', authenticateUser, async (req, res) => {
    try {
      const stats = await storage.getUserStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Error fetching user stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: import('@shared/schema').User;
    }
  }
}
