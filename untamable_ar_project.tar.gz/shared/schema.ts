import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  photoURL: text("photo_url"),
  uid: text("uid").notNull().unique(), // Firebase UID
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define layer type enum
export const layerTypes = [
  'image',
  'video',
  'model3d',
  'audio',
  'text',
  'effect',
  'group'
] as const;

// Define layer schema
export const layerSchema = z.object({
  id: z.string().uuid().optional(), // Generated client-side
  type: z.enum(layerTypes),
  name: z.string().min(1),
  url: z.string().url().optional(), // For media files like images, videos, models, audio
  content: z.string().optional(),   // For text layers or effect configuration
  settings: z.record(z.string(), z.any()).optional(), // For advanced settings like position, scale, etc
  order: z.number().int().min(0),
});

// Artwork table
export const artworks = pgTable("artworks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(), // Main trigger image
  layers: jsonb("layers"), // JSON array of AR layers
  views: integer("views").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define insert schemas
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true });

export const insertArtworkSchema = createInsertSchema(artworks)
  .omit({ id: true, views: true, createdAt: true })
  .extend({
    layers: z.array(layerSchema).default([]),
  });

// Define response schemas with additional validation
export const createArtworkSchema = insertArtworkSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().optional(),
});

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Layer = z.infer<typeof layerSchema>;
export type LayerType = (typeof layerTypes)[number];

export type Artwork = typeof artworks.$inferSelect;
export type InsertArtwork = z.infer<typeof insertArtworkSchema>;
export type CreateArtwork = z.infer<typeof createArtworkSchema>;

// Stats type for dashboard
export type UserStats = {
  totalArtworks: number;
  totalViews: number;
  engagementRate: string;
};
